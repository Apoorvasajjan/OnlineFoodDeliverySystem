package com.edubridge.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.edubridge.model.CustomeIdGenerator;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
@Entity
@Table(name="Restaurant_table")
public class Restaurant {

	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="restaurant_sequence")
	@GenericGenerator( name="restaurant_sequence",strategy="com.edubridge.model.CustomeIdGenerator",parameters= {
			@Parameter(name=com.edubridge.model.CustomeIdGenerator.INCREMENT_PARAM,value="1"),
			@Parameter(name=com.edubridge.model.CustomeIdGenerator.VALUE_PREFIX_PARAMETER,value="Rest_"),
			@Parameter(name=com.edubridge.model.CustomeIdGenerator.NUMBER_FORMAT_PARAMETER,value="%04d")
			
	})
  @Id
  private String restaurantId;
	private String restaurantName;
	
	public Restaurant() {
		
	}
	public Restaurant(String restaurantId, String restaurantName) {
		super();
		this.restaurantId = restaurantId;
		this.restaurantName = restaurantName;
	}
	public String getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getRestaurantName() {
		return restaurantName;
	}
	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}
	@Override
	public String toString() {
		return "Restaurant [restaurantId=" + restaurantId + ", restaurantName=" + restaurantName + "]";
	}
	
	
}

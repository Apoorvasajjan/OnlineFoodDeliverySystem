package com.edubridge.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Order_table")
public class Order {
	@Id
	@SequenceGenerator(name = "seq_order", sequenceName = "OrderSequence", initialValue = 3000, allocationSize = 100)
	@GeneratedValue(generator = "seq_order")
	private long orderId;

	
	  @Column(name="orderDate")
private LocalDateTime orderDate;// *
	 
	@Column(name = "orderStatus")
	private String orderStatus;

	@Column(name = "totalPrice")
	private double totalPrice;

	public Order() {

	}

	public Order(long orderId, LocalDateTime orderDate, String orderStatus, double totalPrice) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.orderStatus = orderStatus;
		this.totalPrice = totalPrice;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public LocalDateTime getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDate=" + orderDate + ", orderStatus=" + orderStatus
				+ ", totalPrice=" + totalPrice + "]";
	}


}

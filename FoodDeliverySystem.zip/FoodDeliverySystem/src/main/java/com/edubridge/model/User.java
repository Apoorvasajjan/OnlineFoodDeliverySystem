package com.edubridge.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

@Entity
@Table(name="User")
public class User {
 
	@Id
	@SequenceGenerator(name="seq_user",sequenceName="UserSequence",initialValue=100,allocationSize=10)
	@GeneratedValue(generator="seq_user")
	private int userId;
	
	@NotEmpty
	@Size(min=3,message="Item name should contain atleast 3 characters")
	@Column(name="firstName")
	private String firstName;
	
	@NotEmpty
	@Size(min=3, message="last name should contain min 3 characters")
	@Column(name="last_name")
	private String lastName;

	@NotEmpty
	@Email(message="email is not valid" )
	@Column(name="email " ,unique=true)
	private String emailId;
	
	@NotEmpty
	@Size(min=10,message="mobile no should contain 10 digits")
	@Column(name="mobileNo",unique=true)
	private String mobileNo;
	
	@Column(name="userName " ,unique=true)
	private String userName;

	 // @ValidPassword
	   //   @NonNull
	@Column(name="password " ,unique=true)
	private String password;
	
	@Column(name="address")
	private String address;
	
	@Column(name="Role")
	public String role;
	
	public User() {
		
	}
	
	public User(int userId,
			 String firstName, String lastName,String emailId,
		 String mobileNo, String userName,
			String password, String address, String role) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.userName = userName;
		this.password = password;
		this.address = address;
		this.role = role;
	}

	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId
				+ ", mobileNo=" + mobileNo + ", userName=" + userName + ", password=" + password + ", address="
				+ address + ", role=" + role + "]";
	}
		
	
}

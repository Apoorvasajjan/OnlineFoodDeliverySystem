package com.edubridge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.edubridge.model.User;
import com.edubridge.service.UserService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/")
public class UserController {

	@Autowired
	private UserService userService;
	
	public UserController(UserService userService)
	{
		super();
		this.userService=userService;
		
	}
	
	@PostMapping
	public ResponseEntity<User> saveUser(@Validated @RequestBody User user){
		
		return new ResponseEntity<User> (userService.addUser(user),HttpStatus.CREATED);
	}
	@PostMapping("/login")
	public ResponseEntity<User> loginUser(@RequestBody User user){
		return new ResponseEntity<User>(userService.loginUser(user),HttpStatus.OK);
	}
	@GetMapping
	public List<User> getAllUsers(){
		return userService.getAllUsers();
		
	}
	
	@GetMapping("{userId}")
	public ResponseEntity<User> getUserByUserId(@PathVariable("userId") int userId)
	{
		return new ResponseEntity<User>(userService.getUserByUserId(userId),HttpStatus.OK);
	}
	
	@DeleteMapping("{userId}")
	public ResponseEntity<String> removeUserByUserId(@PathVariable("userId") int userId)
	{
		userService.removeUserByUserId(userId);
		return new ResponseEntity<String> ("Item deleted successfully",HttpStatus.OK);
		
	}
	@PutMapping("{userId}")
	public ResponseEntity<User> updateUser(@PathVariable("userId") int userId,@RequestBody User user){
		return new ResponseEntity<User>(userService.updateUser(userId, user),HttpStatus.OK);
	}
	
	@GetMapping("getName/{userName}")
	public ResponseEntity<User> findByUserName(@PathVariable("userName") String userName)
	{
		return new ResponseEntity<User>(userService.getUserByUserName(userName),HttpStatus.OK);
	}
	@DeleteMapping("getName/{userName}")
	public ResponseEntity<String> removeUserByUserName(@PathVariable("userName") String userName)
	{
		userService.removeUserByUserName(userName);
		return new ResponseEntity<String> ("Item deleted successfully",HttpStatus.OK);
	}
	
}

package com.edubridge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.model.Restaurant;
import com.edubridge.service.RestaurantService;

@RestController
//@RequestMapping("/admin/api/restaurant")
public class RestaurantController {
	
	    @Autowired
		private RestaurantService restaurantService;

		public RestaurantController(RestaurantService restaurantService) {
			super();
			this.restaurantService = restaurantService;
		}
		//http://localhost:8084/api/restaurant
		@PostMapping("/admin/api/restaurant")
		public ResponseEntity<Restaurant> addRestaurant(@RequestBody Restaurant restaurant)
		{
			
			return new ResponseEntity<Restaurant>(restaurantService.addRestaurant(restaurant),HttpStatus.CREATED);
		}
		
		//http://localhost:8084/api/restaurant
		@GetMapping("/admin/api/restaurant")
		public List<Restaurant> getAllRestaurant()
		{
			return restaurantService.getAllRestaurant();
		}

		
		@GetMapping("/admin/api/restaurant/{restaurantId}")
		public ResponseEntity<Restaurant> getRestaurantById(@PathVariable("restaurantId") String  restaurantId){
			return new ResponseEntity<Restaurant>(restaurantService.getRestaurantById(restaurantId),HttpStatus.OK );
		}
		
		@DeleteMapping("/admin/api/restaurant/{restaurantId}")
		public ResponseEntity<String> removeRestaurantById(@PathVariable("restaurantId") String restaurantId){
			restaurantService.removeRestaurantByRestaurantId(restaurantId);
			return new ResponseEntity<String>("Restaurant deleted successfully" ,HttpStatus.OK );
			
		}
		
		@PutMapping("/admin/api/restaurant/{restaurantId}")
		public ResponseEntity<Restaurant> updateRestaurantById(@PathVariable("restaurantId") String restaurantId,@RequestBody Restaurant restaurant){
			System.out.println("controller");
			return new ResponseEntity<Restaurant>(restaurantService.updateRestaurantByRestaurantId(restaurantId, restaurant),HttpStatus.OK);
		}
		
		 
		
		
}
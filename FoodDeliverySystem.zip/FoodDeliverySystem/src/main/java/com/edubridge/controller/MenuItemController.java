package com.edubridge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.model.MenuItem;
import com.edubridge.service.MenuItemService;
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/admin/")
public class MenuItemController {
	
	@Autowired
	private MenuItemService menuItemService;

	public MenuItemController(MenuItemService menuItemService) {
		super();
		this.menuItemService = menuItemService;
		System.out.println("1111111111");
	}


@PostMapping
public ResponseEntity<MenuItem> addItemByAdmin(@RequestBody MenuItem menuitems)
{
	
	return new ResponseEntity<MenuItem>(menuItemService.addItemByAdmin(menuitems),HttpStatus.CREATED);
}
@GetMapping
public List<MenuItem> getAllMenuItems()
{
	return menuItemService.getAllMenuItems();
	
}
@GetMapping("{item_id}")
public ResponseEntity<MenuItem> getMenuItemById(@PathVariable("item_id") int item_id)
{
	return new ResponseEntity<MenuItem>(menuItemService.getMenuItemById(item_id),HttpStatus.OK);
}
@DeleteMapping("{item_id}")
public List<MenuItem> deleteMenuItemById(@PathVariable("item_id") int item_id)
{
	return menuItemService.deleteMenuItem(item_id);
	 
}

@PutMapping("{item_id}")
public ResponseEntity<MenuItem> updateMenuItemById(@PathVariable("item_id") int item_id,@RequestBody MenuItem menuItem){
	return new ResponseEntity<MenuItem>(menuItemService.updateMenuItem(item_id, menuItem),HttpStatus.OK);
}
@GetMapping("getName/{itemName}")
public ResponseEntity<MenuItem> findMenuItemByItemName(@PathVariable("itemName") String itemName)
{
	return new ResponseEntity<MenuItem>(menuItemService.getMenuItemByName(itemName),HttpStatus.OK);
}
}

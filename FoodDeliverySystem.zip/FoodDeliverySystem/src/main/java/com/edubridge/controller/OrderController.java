
package com.edubridge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.model.Order;
import com.edubridge.service.OrderService;
@CrossOrigin(origins="*")
@RestController

@RequestMapping("/user/api/order")
public class OrderController {

	@Autowired
	private OrderService orderService;

	public OrderController(OrderService orderService) {
		super();
		this.orderService = orderService;
	} // http://localhost:8089/api/Order

	@PostMapping
	public ResponseEntity<Order> saveOrder(@RequestBody Order order) {

		return new ResponseEntity<Order>(orderService.saveOrder(order), HttpStatus.CREATED);
	}

	// http://localhost:8089/api/Order

	@GetMapping
	public List<Order> getAllOrders() {
		return orderService.getAllOrder();
	}

	@GetMapping("{orderId}")
	public ResponseEntity<Order> getOrderById(@PathVariable("orderId") long orderId) {
		return new ResponseEntity<Order>(orderService.getOrderById(orderId), HttpStatus.OK);
	}

	@DeleteMapping("{orderId}")
	public ResponseEntity<String> removeOrderById(@PathVariable("orderId") long orderId) {
		orderService.removeOrderById(orderId);
		return new ResponseEntity<String>("Order deleted successfully", HttpStatus.OK);

	}//https://developer.mozilla.org/en-US/docs/Web/API/Document

	@PutMapping("{orderId}")
	public ResponseEntity<Order> updateOrderById(@PathVariable("orderId") long orderId, @RequestBody Order order) {
		return new ResponseEntity<Order>(orderService.updateOrderById(orderId, order), HttpStatus.OK);
	}

}

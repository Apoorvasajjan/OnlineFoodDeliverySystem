package com.edubridge.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.exception.ResourceNotFoundException;
import com.edubridge.model.Restaurant;
import com.edubridge.repository.RestaurantRepository;
import com.edubridge.service.RestaurantService;

@Service
public class RestaurantServiceimpl implements RestaurantService{

	@Autowired
	private RestaurantRepository restaurantRepository;
	
	public RestaurantServiceimpl(RestaurantRepository restaurantRepository) {
		super();
		this.restaurantRepository = restaurantRepository;
	}

	@Override
	public Restaurant addRestaurant(Restaurant restaurant) {
		
		return restaurantRepository.save(restaurant);
	}

	@Override
	public List<Restaurant> getAllRestaurant() {
		// TODO Auto-generated method stub
		return restaurantRepository.findAll();
	}

	@Override
	public void removeRestaurantByRestaurantId(String restaurantId) {
		// TODO Auto-generated method stub
		Restaurant restaurant=getRestaurantById(restaurantId);
		restaurantRepository.deleteById(restaurantId);
	}

	@Override
	public Restaurant updateRestaurantByRestaurantId(String restaurantId, Restaurant restaurantcart) {
		// TODO Auto-generated method stub
		Restaurant restaurant1=getRestaurantById(restaurantId);
		restaurant1.setRestaurantName(restaurant1.getRestaurantName());
		return restaurantRepository.save(restaurant1);
	}

	@Override
	public Restaurant getRestaurantById(String restaurantId) {
		// TODO Auto-generated method stub
		return restaurantRepository.findById(restaurantId).orElseThrow(()->new ResourceNotFoundException("Restaurant","restaurantId",restaurantId));
	}

}

package com.edubridge.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.model.MenuItem;
import com.edubridge.repository.MenuItemRepository;
import com.edubridge.service.CartService;
import com.edubridge.service.MenuItemService;
import com.edubridge.exception.ResourceNotFoundException;
import com.edubridge.model.Cart;
@Service
public class MenuItemServiceimpl implements MenuItemService{
	@Autowired
	private MenuItemRepository menuItemRepository;

	@Autowired
	private CartService cartService;
	
	public MenuItemServiceimpl(MenuItemRepository menuItemRepsitory) {
		super();
		this.menuItemRepository = menuItemRepository;
	}

	
	@Override
	public List<MenuItem> getAllMenuItems() {
		
		return menuItemRepository.findAll();
	}

	@Override
	public MenuItem getMenuItemById(int item_id) {
		// TODO Auto-generated method stub
		return menuItemRepository.findById(item_id).orElseThrow(()->new ResourceNotFoundException("MenuItem","item_id",item_id));
	}

	@Override
	public List<MenuItem> deleteMenuItem(int item_id) {
		// TODO Auto-generated method stub
		MenuItem menuItem=getMenuItemById(item_id);
		menuItemRepository.deleteById(menuItem.getItem_id());
		return menuItemRepository.findAll();
	}

	@Override
	public MenuItem updateMenuItem(int item_id, MenuItem menuItem) {
		MenuItem menuItem1 = getMenuItemById(item_id);
		menuItem1.setItemName(menuItem.getItemName());
		menuItem1.setItem_quantity(menuItem.getItem_quantity());
		menuItem1.setItem_cost(menuItem.getItem_cost());
		return menuItemRepository.save(menuItem1);
		
	}

	@Override
	public MenuItem getMenuItemByName(String itemName) {
		
		MenuItem menuItem= menuItemRepository.findByItemName(itemName);
		System.out.println(menuItem);
		if(menuItem!=null) {
			return menuItem;
		}
		else
		{
			throw new ResourceNotFoundException("MenuItem","itemName",itemName);
		}
	}

	@Override
	public MenuItem addItemByAdmin(MenuItem menuItem) {
		// TODO Auto-generated method stub
		return menuItemRepository.save(menuItem);
	}


}

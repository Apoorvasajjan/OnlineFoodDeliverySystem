package com.edubridge.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.exception.ResourceNotFoundException;
import com.edubridge.model.Cart;
import com.edubridge.model.Payment;
import com.edubridge.model.User;
import com.edubridge.repository.PaymentRepository;
import com.edubridge.service.CartService;
import com.edubridge.service.PaymentService;
import com.edubridge.service.UserService;
import java.util.Date;
@Service
public class PaymentServiceimpl implements PaymentService{

	@Autowired
	private PaymentRepository paymentRepository;

	@Autowired
	private UserService userService;
	
	@Autowired 
	private CartService cartService;
	public PaymentServiceimpl(PaymentRepository paymentRepository) {
		this.paymentRepository=paymentRepository;
	}

	@Override
	public Payment savePaymentDetails(int cart_id,int userId,Payment payment) {
		//public Payment generatePayment(int cart_id,int userId,Payment payment) {
			System.out.println("inside payment service");
			User user=userService.getUserByUserId(userId);
			Cart cart = cartService.getCartItemByCartId(cart_id);
			payment.setCart_id(cart);
			payment.setUser(user);
			payment.setAmount(cart.getTotal_cost());
			payment.setPaymentDate(new Date());
			return paymentRepository.save(payment);
	
		
	}

	@Override
	public List<Payment> getAllPaymentDetails() {
		return paymentRepository.findAll();
	}

	@Override
	public Payment getPaymentById(int paymentId) {
		return paymentRepository.findById(paymentId).orElseThrow(()->new ResourceNotFoundException("Payment","paymentId",paymentId));
	}

	@Override
	public void cancelPaymentById(int paymentId) {
		paymentRepository.deleteById(paymentId);
		
	}

	@Override
	public Payment updatePaymentById(int paymentId, Payment payment) {
		Payment payment1 = getPaymentById(paymentId);
		  payment1.setPaymentMode(payment.getPaymentMode());
		  payment1.setAmount( payment.getAmount());
		  
			return paymentRepository.save(payment1);
	}

}

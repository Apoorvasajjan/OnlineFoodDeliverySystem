
  package com.edubridge.service.impl;
  
  import java.util.List;
  
  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.stereotype.Service;
  
  import com.edubridge.exception.ResourceNotFoundException; 
 
  import com.edubridge.model.Order;
  
  import com.edubridge.repository.OrderRepository;
  import com.edubridge.service.OrderService;
  
  @Service
  public class OrderServiceimpl implements OrderService{
  
  
  @Autowired 
  private OrderRepository orderRepository;
  
  
  public OrderServiceimpl(OrderRepository orderRepository) { 
	  super();
  this.orderRepository = orderRepository; }
  
  @Override 
  public Order saveOrder(Order order) {
	  return orderRepository.save(order); }
  
  @Override 
  public List<Order> getAllOrder() { 
	  return orderRepository.findAll(); }
  
  @Override 
  public Order getOrderById(long orderId) { 
	  return orderRepository.findById(orderId).orElseThrow(()->new ResourceNotFoundException("Order","orderId",orderId)); }
 
  @Override
  public void removeOrderById(long orderId) { 
	  Order order=getOrderById(orderId); 
	  orderRepository.deleteById(order.getOrderId()); }
  
  @Override
  public Order updateOrderById(long orderId, Order order) { 
	  Order order1 =getOrderById(orderId);
	 // order1.setOrderDate(order.getOrderDate());
  order1.setOrderStatus(order.getOrderStatus());
  order1.setTotalPrice(order.getTotalPrice());
  return orderRepository.save(order1); 
  }
  
  }
 

  package com.edubridge.service;
  
  import java.util.List;
  
  
  import com.edubridge.model.Order;
  
  public interface OrderService { 
	  public Order saveOrder(Order order); 
  public List<Order> getAllOrder(); 
  public Order getOrderById(long orderId);
  public void removeOrderById(long orderId); 
  public Order updateOrderById(long orderId,Order order);
  }
  
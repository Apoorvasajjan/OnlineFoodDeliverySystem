package com.edubridge.service;

import java.util.List;
import com.edubridge.model.Restaurant;

public interface RestaurantService {

	public Restaurant addRestaurant(Restaurant restaurant);
	public List<Restaurant> getAllRestaurant();
	//public Restaurant getRestaurantById(int restaurantId);
	public void removeRestaurantByRestaurantId(String restaurantId);
	public Restaurant updateRestaurantByRestaurantId(String restaurantId,Restaurant restaurantcart);
	Restaurant getRestaurantById(String restaurantId);
}

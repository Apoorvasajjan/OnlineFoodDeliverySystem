package com.edubridge.service;

import java.util.List;

import com.edubridge.model.MenuItem;

public interface MenuItemService {
	
public MenuItem addItemByAdmin(MenuItem menuItem);
public List<MenuItem> getAllMenuItems();
public MenuItem getMenuItemById(int item_id);
public List<MenuItem> deleteMenuItem(int item_id);
public MenuItem updateMenuItem(int item_id,MenuItem menuItem);
public MenuItem getMenuItemByName(String itemName); 
}

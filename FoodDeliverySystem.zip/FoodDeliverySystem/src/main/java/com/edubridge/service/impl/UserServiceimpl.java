package com.edubridge.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.edubridge.exception.ResourceNotFoundException;
import com.edubridge.model.User;
import com.edubridge.repository.UserRepository;
import com.edubridge.service.UserService;

@Service
public class UserServiceimpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	public UserServiceimpl(UserRepository userRepository) {
		super();
		this.userRepository=userRepository;
	}
	@Override
	public User addUser(User user) {
	return userRepository.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		
		return userRepository.findAll();
	}

	@Override
	public User getUserByUserId(int userId) {
		
		return userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("User","userId",userId));
	}

	@Override
	public void removeUserByUserId(int userId) {
		User user=getUserByUserId(userId);
		userRepository.deleteById(user.getUserId());
		
	}

	@Override
	public User updateUser(int userId, User user) {
		User user1=getUserByUserId(userId);
		user1.setFirstName(user.getFirstName());
		user1.setLastName(user.getLastName());
		user1.setEmailId(user.getEmailId());
		user1.setMobileNo(user.getMobileNo());
		user1.setUserName(user.getUserName());
		user1.setPassword(user.getPassword());
		user1.setAddress(user.getAddress());
	
		return userRepository.save(user1);
		
	}

	@Override
	public User getUserByUserName(String userName) {
			
			//MenuItem menuItem= menuItemRepository.findByItemName(itemName);
			//System.out.println(menuItem);
			/*
			 * if(menuItem!=null) { return menuItem; } else { throw new
			 * ResourceNotFoundException("MenuItem","itemName",itemName); }
			 */
		User user=userRepository.findByUserName(userName);
		System.out.println(user);
		if(user!=null) {
			return user;
		}
		else
		{
			throw new ResourceNotFoundException("User","userName",userName);
		}
	}
	
	@Override
	public void removeUserByUserName(String userName) {
		User user1=getUserByUserName(userName);
		System.out.println(userName);
		if(user1!=null) {
		userRepository.delete(user1);
		
		}else
		{
			throw new ResourceNotFoundException("User","userName",userName);	
		}
	}
	@Override
	public User loginUser(User user) {
		return userRepository.findByUserNameAndPassword(user.getUserName(),user.getPassword() );
	
	}
	

}

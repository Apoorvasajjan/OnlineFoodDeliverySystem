package com.edubridge.service;

import java.util.List;

import com.edubridge.model.Payment;

public interface PaymentService {
	public Payment savePaymentDetails(int cart_id,int userId,Payment payment);
	public List<Payment> getAllPaymentDetails();
	public Payment getPaymentById(int paymentId);
    public void cancelPaymentById(int paymentId);
    public Payment updatePaymentById(int paymentId,Payment payment);
}

package com.edubridge.repository;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;

import com.edubridge.model.MenuItem;

//@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem,Integer>{
public MenuItem findByItemName(String itemName);

}
